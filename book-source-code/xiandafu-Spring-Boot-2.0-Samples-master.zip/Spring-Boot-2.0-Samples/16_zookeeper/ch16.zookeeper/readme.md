http://zookeeper.apache.org/
http://curator.apache.org/

版本信息：
zookeeper-3.4.11
curator:4.0.1
