package com.bee.sample.ch16;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ch16Application {

	public static void main(String[] args) {
		SpringApplication.run(Ch16Application.class, args);
	}
}
