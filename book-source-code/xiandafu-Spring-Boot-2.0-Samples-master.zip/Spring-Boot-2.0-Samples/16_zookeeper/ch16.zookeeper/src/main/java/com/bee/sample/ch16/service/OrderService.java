package com.bee.sample.ch16.service;

public interface OrderService {
	public void makeOrderType(String type);
}
