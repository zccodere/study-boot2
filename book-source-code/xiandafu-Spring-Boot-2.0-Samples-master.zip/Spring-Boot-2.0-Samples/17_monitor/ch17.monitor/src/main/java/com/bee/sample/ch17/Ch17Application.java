package com.bee.sample.ch17;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ch17Application {

	public static void main(String[] args) {
		SpringApplication.run(Ch17Application.class, args);
	}
}
