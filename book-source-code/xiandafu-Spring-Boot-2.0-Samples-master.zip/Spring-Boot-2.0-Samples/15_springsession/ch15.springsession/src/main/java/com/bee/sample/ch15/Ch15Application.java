package com.bee.sample.ch15;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ch15Application {

	public static void main(String[] args) {
		SpringApplication.run(Ch15Application.class, args);

	}

}
