package com.bee.sample.ch13;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ch13Application {

	public static void main(String[] args) {
		SpringApplication.run(Ch13Application.class, args);

	}

}
