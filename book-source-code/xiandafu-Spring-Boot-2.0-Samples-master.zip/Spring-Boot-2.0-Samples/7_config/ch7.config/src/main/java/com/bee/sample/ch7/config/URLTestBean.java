package com.bee.sample.ch7.config;

/**
 * 用于演示采用java config 配置此类
 * @author xiandafu
 *
 */
public class URLTestBean {
	
}
