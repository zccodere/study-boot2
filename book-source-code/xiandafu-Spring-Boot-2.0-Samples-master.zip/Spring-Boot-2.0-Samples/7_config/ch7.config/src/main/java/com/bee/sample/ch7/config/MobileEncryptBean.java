package com.bee.sample.ch7.config;

public class MobileEncryptBean {
	public String getMobile(String mobile){
		return mobile;
	}
}
