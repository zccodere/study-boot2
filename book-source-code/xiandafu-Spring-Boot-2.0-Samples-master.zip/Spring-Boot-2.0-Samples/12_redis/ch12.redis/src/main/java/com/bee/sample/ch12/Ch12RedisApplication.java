package com.bee.sample.ch12;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ch12RedisApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ch12RedisApplication.class, args);
	}
}
