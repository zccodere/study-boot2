package com.bee.sample.ch9.dao;

import org.beetl.sql.core.mapper.BaseMapper;

import com.bee.sample.ch9.entity.User;

public interface UserDao extends BaseMapper<User> {

}
