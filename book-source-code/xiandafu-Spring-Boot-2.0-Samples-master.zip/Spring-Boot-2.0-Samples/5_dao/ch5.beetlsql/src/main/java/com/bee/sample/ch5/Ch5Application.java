package com.bee.sample.ch5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ch5Application {

	public static void main(String[] args) {
		SpringApplication.run(Ch5Application.class, args);

	}

}
