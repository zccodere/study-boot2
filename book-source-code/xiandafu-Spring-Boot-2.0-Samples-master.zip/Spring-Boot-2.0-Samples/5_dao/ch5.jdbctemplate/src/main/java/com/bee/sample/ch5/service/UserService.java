package com.bee.sample.ch5.service;

import com.bee.sample.ch5.entity.User;

public interface UserService {
	public User geUserById(Long id) ;
	
}
